#!/usr/bin/env python3
"""
Soluciona no GLPI os chamados PENDENTES ha N dias (padrao: 1) sem retorno do cliente.

Para cada chamado com status Pendente:
  1. calcula ha quanto tempo ele esta pendente (desde a "data de inicio da espera");
  2. confere se o requerente respondeu depois disso;
  3. se passou do prazo e nao houve resposta, registra uma SOLUCAO no chamado.
     O status muda para Solucionado e o cliente ainda pode recusar (o chamado reabre).

Usa o MESMO glpi_config.ini do script de fechamento (mesma pasta):
  - conexao: secao [glpi] (url, app_token, user_token, verificar_ssl)
  - ajustes deste script: secao [pendentes] (dias, solucao) - opcional

Uso:
    python3 solucionar_pendentes.py            # simulacao (nao altera nada)
    python3 solucionar_pendentes.py --executar # soluciona de verdade
"""
import argparse
import configparser
import html
import os
import re
import sys
import time
from datetime import datetime, timedelta

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

PASTA = os.path.dirname(os.path.abspath(__file__))
ARQ_CONFIG = os.path.join(PASTA, "glpi_config.ini")
ARQ_LOG = os.path.join(PASTA, "solucionar_pendentes.log")
STATUS_PENDENTE = 4
CAMPO_ID, CAMPO_STATUS = 2, 12
FMT = "%Y-%m-%d %H:%M:%S"
TEXTO_PADRAO = ("Chamado solucionado automaticamente: aguardamos o seu retorno por {dias} dia(s), desde {desde}, "
                "sem resposta. Se o problema continuar, recuse esta solução que o atendimento será retomado.")


def log(msg):
    linha = f"{datetime.now():%Y-%m-%d %H:%M:%S} {msg}"
    print(linha)
    with open(ARQ_LOG, "a", encoding="utf-8") as f:
        f.write(linha + "\n")


def carregar_config():
    if not os.path.exists(ARQ_CONFIG):
        sys.exit(f"Arquivo de configuracao nao encontrado: {ARQ_CONFIG}")
    cfg = configparser.ConfigParser(interpolation=None)
    cfg.read(ARQ_CONFIG, encoding="utf-8")
    if not cfg.has_section("glpi"):
        sys.exit(f"Secao [glpi] nao encontrada em {ARQ_CONFIG}")
    g = cfg["glpi"]
    # ajustes deste script ficam na secao [pendentes]; o "dias" da secao [glpi] e do fechamento
    p = cfg["pendentes"] if cfg.has_section("pendentes") else {}
    conf = {
        "url": g.get("url", "").strip().rstrip("/"),
        "app_token": g.get("app_token", "").strip(),
        "user_token": g.get("user_token", "").strip(),
        "verificar_ssl": g.getboolean("verificar_ssl", False),
        "timeout": g.getint("timeout", 90),
        "dias": float(p.get("dias", 1)),
        "solucao": str(p.get("solucao", TEXTO_PADRAO)).strip(),
    }
    for chave in ("url", "user_token"):
        if not conf[chave] or conf[chave].startswith("COLE_"):
            sys.exit(f"Preencha '{chave}' em {ARQ_CONFIG}")
    if conf["app_token"].startswith("COLE_"):
        sys.exit(f"Preencha 'app_token' em {ARQ_CONFIG} (ou deixe em branco se o cliente da API nao usa)")
    return conf


def data(valor):
    try:
        return datetime.strptime(str(valor)[:19], FMT) if valor else None
    except ValueError:
        return None


class Glpi:
    def __init__(self, conf):
        self.conf = conf
        self.base = {"Content-Type": "application/json"}
        if conf["app_token"]:
            self.base["App-Token"] = conf["app_token"]
        self.headers = None

    def chamar(self, metodo, caminho, headers=None, ok=(200, 201, 206), **kw):
        for tentativa in range(1, 4):
            try:
                r = requests.request(metodo, f"{self.conf['url']}/{caminho}", headers=headers or self.headers,
                                     verify=self.conf["verificar_ssl"], timeout=self.conf["timeout"], **kw)
                break
            except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
                if tentativa == 3:
                    log(f"ERRO: o GLPI nao respondeu em {caminho}: {e}")
                    sys.exit(1)
                time.sleep(5 * tentativa)
        if r.status_code not in ok:
            log(f"ERRO {r.status_code} em {caminho} - RESPOSTA DO GLPI: {r.text[:300]}")
            return None
        return r

    def __enter__(self):
        h = dict(self.base, Authorization=f"user_token {self.conf['user_token']}")
        r = self.chamar("GET", "initSession", headers=h)
        if r is None:
            sys.exit(1)
        self.headers = dict(self.base, **{"Session-Token": r.json()["session_token"]})
        self.chamar("POST", "changeActiveEntities", json={"entities_id": 0, "is_recursive": True}, ok=(200, 201, 400))
        return self

    def __exit__(self, *a):
        self.chamar("GET", "killSession", ok=(200, 400, 401))

    def lista(self, caminho):
        r = self.chamar("GET", caminho)
        dados = r.json() if r is not None else []
        return dados if isinstance(dados, list) else []

    def pendentes(self):
        ids, inicio, passo = [], 0, 500
        while True:
            params = {"criteria[0][field]": CAMPO_STATUS, "criteria[0][searchtype]": "equals",
                      "criteria[0][value]": STATUS_PENDENTE, "forcedisplay[0]": CAMPO_ID,
                      "range": f"{inicio}-{inicio + passo - 1}"}
            r = self.chamar("GET", "search/Ticket", params=params, ok=(200, 206, 400))
            if r is None or r.status_code == 400:
                break
            dados = r.json()
            ids += [int(l[str(CAMPO_ID)]) for l in dados.get("data", []) if l.get(str(CAMPO_ID))]
            inicio += passo
            if inicio >= int(dados.get("totalcount", 0)):
                break
        return ids


def resumo(texto, limite=60):
    t = re.sub(r"<[^>]+>", " ", html.unescape(html.unescape(str(texto or ""))))
    t = re.sub(r"\s+", " ", t).strip()
    return t if len(t) <= limite else t[:limite] + "…"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--executar", action="store_true", help="Soluciona de verdade (sem isso, apenas simula)")
    args = parser.parse_args()

    conf = carregar_config()
    agora = datetime.now()
    limite = agora - timedelta(days=conf["dias"])
    modo = "EXECUCAO" if args.executar else "SIMULACAO"
    log(f"[{modo}] Inicio: pendentes desde antes de {limite:%d/%m/%Y %H:%M} sem retorno do cliente.")

    alvos, sem_data, respondidos, recentes = [], 0, 0, 0
    with Glpi(conf) as g:
        ids = g.pendentes()
        log(f"{len(ids)} chamado(s) pendente(s) encontrado(s).")
        for tid in ids:
            r = g.chamar("GET", f"Ticket/{tid}")
            if r is None:
                continue
            t = r.json()
            if int(t.get("status") or 0) != STATUS_PENDENTE:
                continue  # mudou de status durante a execucao
            desde = data(t.get("begin_waiting_date"))
            if desde is None:
                sem_data += 1
                log(f"  Chamado {tid}: pendente sem 'data de inicio da espera' no GLPI. Ignorado.")
                continue
            if desde > limite:
                recentes += 1
                continue
            requerentes = {a.get("users_id") for a in g.lista(f"Ticket/{tid}/Ticket_User")
                           if a.get("type") == 1 and a.get("users_id")}
            resposta = [f for f in g.lista(f"Ticket/{tid}/ITILFollowup")
                        if f.get("users_id") in requerentes
                        and (data(f.get("date_creation") or f.get("date")) or datetime.min) >= desde]
            if resposta:
                respondidos += 1
                log(f"  Chamado {tid}: o cliente respondeu depois de ficar pendente. Ignorado.")
                continue
            dias_parado = (agora - desde).total_seconds() / 86400
            alvos.append((tid, desde))
            log(f"  Chamado {tid} - pendente desde {desde:%d/%m/%Y %H:%M} ({dias_parado:.1f} dias) - {resumo(t.get('name'))}")

        log(f"Resumo: {len(alvos)} para solucionar | {recentes} pendente(s) ha menos de {conf['dias']:g} dia(s) | "
            f"{respondidos} com resposta do cliente | {sem_data} sem data de inicio da espera.")

        if not alvos:
            log("Nada a fazer.")
            return
        if not args.executar:
            log("Simulacao: nada foi alterado. Rode com --executar para solucionar.")
            return

        ok = falhas = 0
        for tid, desde in alvos:
            texto = conf["solucao"].format(dias=f"{conf['dias']:g}", desde=desde.strftime("%d/%m/%Y %H:%M"))
            corpo = {"input": {"itemtype": "Ticket", "items_id": tid, "content": texto}}
            r = g.chamar("POST", "ITILSolution", json=corpo)
            if r is None:
                falhas += 1
                log(f"  Chamado {tid}: FALHOU ao registrar a solucao.")
            else:
                ok += 1
                log(f"  Chamado {tid}: solucionado.")
            time.sleep(0.3)
        log(f"Concluido: {ok} solucionado(s), {falhas} falha(s).")


if __name__ == "__main__":
    main()

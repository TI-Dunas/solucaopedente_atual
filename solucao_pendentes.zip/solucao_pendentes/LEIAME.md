# Solucionar chamados pendentes sem retorno do cliente

Fica na **mesma pasta do script de fechamento** e usa o **mesmo glpi_config.ini**.

## Instalação

```bash
cd /root/solucoes_glpi/solucaofecha_atual3
# copie para esta pasta: solucionar_pendentes.py
```

Opcional: para mudar o prazo ou o texto da solução, acrescente ao glpi_config.ini:

```bash
cat >> glpi_config.ini << 'FIM'

[pendentes]
# Solucionar chamados pendentes ha pelo menos quantos dias, sem resposta do cliente
dias = 1
FIM
```

Sem essa seção, o script usa 1 dia e o texto padrão. O `dias = 3` da seção `[glpi]`
continua sendo o do fechamento.

## Teste (simulação: não altera nada)

```bash
python3 solucionar_pendentes.py
```

## Agendamento diário às 2h (rode uma única vez)

```bash
(crontab -l 2>/dev/null; echo "0 2 * * * /usr/bin/python3 /root/solucoes_glpi/solucaofecha_atual3/solucionar_pendentes.py --executar") | crontab -
crontab -l
```

Registro de cada execução: `solucionar_pendentes.log`, na mesma pasta.
